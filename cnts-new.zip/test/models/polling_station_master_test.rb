require 'test_helper'

class PollingStationMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
