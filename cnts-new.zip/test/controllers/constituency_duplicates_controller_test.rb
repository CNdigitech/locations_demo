require 'test_helper'

class ConstituencyDuplicatesControllerTest < ActionDispatch::IntegrationTest
  # test "the truth" do
  #   assert true
  # end
end
