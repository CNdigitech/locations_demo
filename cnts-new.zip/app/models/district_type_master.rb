class DistrictTypeMaster < ApplicationRecord
end
