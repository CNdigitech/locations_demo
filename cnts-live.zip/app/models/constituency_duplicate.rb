class ConstituencyDuplicate < ApplicationRecord
    # self.table_name = "constituency_duplicates"
end
