require 'test_helper'

class DistrictMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
