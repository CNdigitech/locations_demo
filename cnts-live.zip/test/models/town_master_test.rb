require 'test_helper'

class TownMasterTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
