require 'test_helper'

class PollingStationAgentTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
