require 'test_helper'

class ConstituencyTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
